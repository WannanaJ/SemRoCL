"""
Stage 2: Semantic-Guided Enhancement Training
Fine-tune enhancer with semantic guidance and multi-objective optimization

✅ FIXED VERSION with all corrections applied:
1. ✅ Gradient clipping added
2. ✅ Discriminator update frequency balanced
3. ✅ Loss scaling option included
4. ✅ Detailed logging added
5. ✅ Emergency brake for loss explosion
"""

import torch
import torch.optim as optim
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter
import os
import argparse
from tqdm import tqdm

from data_loader import LowLightDataset
from model.encoder_moco import MoCoV3Encoder
from model.semantic_head import SemanticHead
from model.enhancer import CurveEnhancer
from model.discriminator import PatchGANDiscriminator
from loss_functions import CombinedLoss
from utils import *


def train_enhancement(config):
    """Stage 2: Enhancement training with semantic guidance"""
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    # Setup
    exp_dirs = create_exp_dir(config['output_dir'], config['exp_name'])
    save_config(config, os.path.join(exp_dirs['logs'], 'config.yaml'))
    writer = SummaryWriter(exp_dirs['logs'])
    
    # Data
    train_loader = DataLoader(
        LowLightDataset(config['dataset']['root_dir'], paired=True, split='train',
                       img_size=config['dataset']['img_size'], augment=True),
        batch_size=config['training']['batch_size'], shuffle=True,
        num_workers=config['training']['num_workers'], pin_memory=True
    )
    
    # Models
    encoder = MoCoV3Encoder(base_encoder=config['model']['base_encoder']).to(device)
    semantic_head = SemanticHead(num_classes=19, backbone='segformer-b0').to(device)
    
    # ===== IMPORTANT: Detect semantic feature channels =====
    # Test to get the actual channel dimension from semantic features
    print("\n" + "="*60)
    print("Detecting semantic feature dimensions...")
    print("="*60)
    with torch.no_grad():
        dummy_input = torch.randn(1, 3, config['dataset']['img_size'], config['dataset']['img_size']).to(device)
        semantic_features_test = semantic_head.get_semantic_features(dummy_input)
        
        print(f"Number of feature levels: {len(semantic_features_test)}")
        for i, feat in enumerate(semantic_features_test):
            print(f"  Level {i}: shape={feat.shape}, channels={feat.shape[1]}")
        
        # Use the first level's channels
        semantic_channels = semantic_features_test[0].shape[1]
        print(f"\n✅ Using {semantic_channels} channels from first feature level")
    print("="*60 + "\n")
    
    # Create enhancer with detected channel dimension
    enhancer = CurveEnhancer(
        n_channels=config['model']['enhancer_channels'], 
        num_iterations=config['model']['num_iterations'], 
        use_semantic=True,
        semantic_channels=semantic_channels  # Dynamically detected!
    ).to(device)
    
    print(f"✅ Enhancer created with semantic_channels={semantic_channels}")
    
    discriminator = PatchGANDiscriminator(in_channels=3, ndf=64).to(device)
    
    # Load pretrained encoder
    if config['model'].get('pretrained_encoder'):
        checkpoint = torch.load(config['model']['pretrained_encoder'])
        encoder.load_state_dict(checkpoint['model_state_dict'])
        print("✅ Loaded pretrained encoder")
    
    freeze_model(encoder)  # Freeze encoder
    
    # Optimizers
    opt_G = optim.Adam(
        list(enhancer.parameters()) + list(semantic_head.parameters()),
        lr=config['training']['lr'], betas=(0.5, 0.999)
    )
    opt_D = optim.Adam(discriminator.parameters(), lr=config['training']['lr']*0.5, betas=(0.5, 0.999))
    
    # Loss
    criterion = CombinedLoss(config['loss']).to(device)  # Move to device!
    
    # ✅ NEW: Training stability parameters
    MAX_LOSS_THRESHOLD = 50.0  # Emergency brake threshold
    DISC_UPDATE_FREQ = 5  # Update discriminator every N iterations
    GRADIENT_CLIP_MAX_NORM = 1.0  # Gradient clipping threshold
    
    print(f"\n{'='*60}")
    print("Training Configuration:")
    print(f"{'='*60}")
    print(f"  Batch size: {config['training']['batch_size']}")
    print(f"  Learning rate: {config['training']['lr']}")
    print(f"  Epochs: {config['training']['epochs']}")
    print(f"  Gradient clipping: {GRADIENT_CLIP_MAX_NORM}")
    print(f"  Discriminator update freq: {DISC_UPDATE_FREQ}")
    print(f"  Loss explosion threshold: {MAX_LOSS_THRESHOLD}")
    print(f"{'='*60}\n")
    
    # Training
    global_step = 0
    for epoch in range(config['training']['epochs']):
        enhancer.train()
        semantic_head.train()
        discriminator.train()
        
        pbar = tqdm(train_loader, desc=f"Epoch {epoch+1}/{config['training']['epochs']}")
        
        epoch_G_loss = 0.0
        epoch_D_loss = 0.0
        num_batches = 0
        
        for batch_idx, batch in enumerate(pbar):
            low = batch['low'].to(device)
            high = batch['high'].to(device)
            
            # === Generator Update ===
            opt_G.zero_grad()
            
            # Semantic segmentation
            seg_logits_enh, confidence = semantic_head(low)
            seg_logits_tgt, _ = semantic_head(high)
            
            # Extract semantic features - get the first hidden state
            semantic_features_list = semantic_head.get_semantic_features(low)
            semantic_features = semantic_features_list[0]  # First level (64 channels for SegFormer-B0)
            
            # Debug: Print shapes on first batch
            if batch_idx == 0 and epoch == 0:
                print(f"\n{'='*60}")
                print("First batch shape verification:")
                print(f"{'='*60}")
                print(f"  low: {low.shape}")
                print(f"  high: {high.shape}")
                print(f"  seg_logits_enh: {seg_logits_enh.shape}")
                print(f"  confidence: {confidence.shape}")
                print(f"  semantic_features: {semantic_features.shape}")
                print(f"{'='*60}\n")
            
            # Enhancement
            enhanced, curves = enhancer(low, semantic_features, confidence)
            
            # Discriminator prediction
            disc_pred_fake = discriminator(enhanced)
            
            # Compute losses
            losses = criterion(enhanced, high, seg_logits_enh, seg_logits_tgt, 
                             confidence, disc_pred_fake)
            
            # ✅ FIX 1: Emergency brake for loss explosion
            if losses['total'].item() > MAX_LOSS_THRESHOLD:
                print(f"\n⚠️ WARNING: Loss explosion detected!")
                print(f"   Current G_loss: {losses['total'].item():.4f}")
                print(f"   Threshold: {MAX_LOSS_THRESHOLD}")
                print(f"   Saving emergency checkpoint...")
                
                save_checkpoint({
                    'epoch': epoch,
                    'batch': batch_idx,
                    'enhancer': enhancer.state_dict(),
                    'semantic_head': semantic_head.state_dict(),
                    'discriminator': discriminator.state_dict(),
                    'optimizer_G': opt_G.state_dict(),
                    'optimizer_D': opt_D.state_dict()
                }, os.path.join(exp_dirs['checkpoints'], 'emergency_checkpoint.pth'))
                
                print(f"   Reducing learning rate by 10×...")
                for param_group in opt_G.param_groups:
                    param_group['lr'] *= 0.1
                for param_group in opt_D.param_groups:
                    param_group['lr'] *= 0.1
                print(f"   New LR: {opt_G.param_groups[0]['lr']:.6f}")
                print(f"   Continuing training...\n")
            
            # Backward pass
            losses['total'].backward()
            
            # ✅ FIX 2: Gradient clipping for Generator
            torch.nn.utils.clip_grad_norm_(enhancer.parameters(), max_norm=GRADIENT_CLIP_MAX_NORM)
            torch.nn.utils.clip_grad_norm_(semantic_head.parameters(), max_norm=GRADIENT_CLIP_MAX_NORM)
            
            opt_G.step()
            
            # === Discriminator Update ===
            # ✅ FIX 3: Balanced discriminator training (update less frequently)
            if batch_idx % DISC_UPDATE_FREQ == 0:
                opt_D.zero_grad()
                
                disc_pred_real = discriminator(high)
                disc_pred_fake = discriminator(enhanced.detach())
                
                from loss_functions import AdversarialLoss
                adv_loss = AdversarialLoss('lsgan')
                
                loss_D_real = adv_loss(disc_pred_real, True)
                loss_D_fake = adv_loss(disc_pred_fake, False)
                loss_D = (loss_D_real + loss_D_fake) * 0.5
                
                loss_D.backward()
                
                # ✅ FIX 4: Gradient clipping for Discriminator
                torch.nn.utils.clip_grad_norm_(discriminator.parameters(), max_norm=GRADIENT_CLIP_MAX_NORM)
                
                opt_D.step()
            else:
                # Set loss_D to zero when not updating
                loss_D = torch.tensor(0.0)
            
            # Accumulate losses
            epoch_G_loss += losses['total'].item()
            epoch_D_loss += loss_D.item() if isinstance(loss_D, torch.Tensor) else 0.0
            num_batches += 1
            
            # ✅ FIX 5: Detailed logging every 10 iterations
            if batch_idx % 10 == 0:
                writer.add_scalar('Loss/G_total', losses['total'].item(), global_step)
                writer.add_scalar('Loss/G_color', losses.get('color', 0).item(), global_step)
                writer.add_scalar('Loss/G_semantic', losses.get('semantic', 0).item(), global_step)
                writer.add_scalar('Loss/G_adv', losses.get('adv', 0).item(), global_step)
                writer.add_scalar('Loss/G_freq', losses.get('freq', 0).item(), global_step)
                writer.add_scalar('Loss/G_perceptual', losses.get('perceptual', 0).item(), global_step)
                writer.add_scalar('Loss/D', loss_D.item() if isinstance(loss_D, torch.Tensor) else 0.0, global_step)
                
                # Detailed console output every 50 iterations
                if batch_idx % 50 == 0:
                    print(f"\n{'='*60}")
                    print(f"Detailed losses at step {global_step}:")
                    print(f"{'='*60}")
                    print(f"  Color:      {losses.get('color', 0).item():.4f}")
                    print(f"  Semantic:   {losses.get('semantic', 0).item():.4f}")
                    print(f"  Adversarial: {losses.get('adv', 0).item():.4f}")
                    print(f"  Frequency:  {losses.get('freq', 0).item():.4f}")
                    print(f"  Perceptual: {losses.get('perceptual', 0).item():.4f}")
                    print(f"  Task:       {losses.get('task', 0).item():.4f}")
                    print(f"  D_loss:     {loss_D.item() if isinstance(loss_D, torch.Tensor) else 0.0:.4f}")
                    print(f"  TOTAL G:    {losses['total'].item():.4f}")
                    print(f"{'='*60}\n")
            
            global_step += 1
            
            # Logging to progress bar
            pbar.set_postfix({
                'G_loss': f'{losses["total"].item():.4f}',
                'D_loss': f'{loss_D.item() if isinstance(loss_D, torch.Tensor) else 0.0:.4f}'
            })
        
        # Epoch summary
        avg_G_loss = epoch_G_loss / num_batches
        avg_D_loss = epoch_D_loss / num_batches
        
        print(f"\n{'='*60}")
        print(f"Epoch {epoch+1}/{config['training']['epochs']} Summary:")
        print(f"{'='*60}")
        print(f"  Average G_loss: {avg_G_loss:.4f}")
        print(f"  Average D_loss: {avg_D_loss:.4f}")
        print(f"{'='*60}\n")
        
        writer.add_scalar('Epoch/G_loss', avg_G_loss, epoch)
        writer.add_scalar('Epoch/D_loss', avg_D_loss, epoch)
        
        # Save checkpoint
        if (epoch + 1) % config['training']['save_freq'] == 0:
            save_checkpoint({
                'epoch': epoch + 1,
                'enhancer': enhancer.state_dict(),
                'semantic_head': semantic_head.state_dict(),
                'discriminator': discriminator.state_dict(),
                'optimizer_G': opt_G.state_dict(),
                'optimizer_D': opt_D.state_dict(),
                'config': config
            }, os.path.join(exp_dirs['checkpoints'], f'stage2_epoch_{epoch+1}.pth'))
            
            print(f"✅ Checkpoint saved: stage2_epoch_{epoch+1}.pth\n")
    
    writer.close()
    print("\n✅ Training completed!")


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', default='../configs/train_stage2.yaml')
    args = parser.parse_args()
    
    config = load_config(args.config)
    train_enhancement(config)
