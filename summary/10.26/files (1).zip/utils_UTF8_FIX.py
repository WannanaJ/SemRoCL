"""
Utility functions for SemRoCL
FIXED: UTF-8 encoding support
"""

import os
import yaml
import torch
import shutil
from datetime import datetime


def load_config(config_path):
    """Load YAML configuration file with UTF-8 encoding"""
    with open(config_path, 'r', encoding='utf-8') as f:  # Added encoding='utf-8'
        config = yaml.safe_load(f)
    return config


def save_config(config, save_path):
    """Save configuration to YAML file with UTF-8 encoding"""
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    with open(save_path, 'w', encoding='utf-8') as f:  # Added encoding='utf-8'
        yaml.dump(config, f, default_flow_style=False)


def create_exp_dir(output_dir, exp_name):
    """Create experiment directory structure"""
    exp_dir = os.path.join(output_dir, exp_name)
    
    dirs = {
        'root': exp_dir,
        'checkpoints': os.path.join(exp_dir, 'checkpoints'),
        'logs': os.path.join(exp_dir, 'logs'),
        'samples': os.path.join(exp_dir, 'samples')
    }
    
    for dir_path in dirs.values():
        os.makedirs(dir_path, exist_ok=True)
    
    return dirs


def save_checkpoint(state, filepath):
    """Save model checkpoint"""
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    torch.save(state, filepath)
    print(f"Checkpoint saved: {filepath}")


def load_checkpoint(filepath, device='cuda'):
    """Load model checkpoint"""
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"Checkpoint not found: {filepath}")
    
    checkpoint = torch.load(filepath, map_location=device)
    print(f"Checkpoint loaded: {filepath}")
    return checkpoint


def freeze_model(model):
    """Freeze model parameters"""
    for param in model.parameters():
        param.requires_grad = False
    model.eval()


def unfreeze_model(model):
    """Unfreeze model parameters"""
    for param in model.parameters():
        param.requires_grad = True
    model.train()


def get_lr(optimizer):
    """Get current learning rate from optimizer"""
    for param_group in optimizer.param_groups:
        return param_group['lr']


def set_lr(optimizer, lr):
    """Set learning rate for optimizer"""
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr


class AverageMeter:
    """Compute and store the average and current value"""
    
    def __init__(self):
        self.reset()
    
    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0
    
    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count


def save_images(images, save_dir, epoch, prefix='sample'):
    """Save sample images"""
    os.makedirs(save_dir, exist_ok=True)
    
    import torchvision.utils as vutils
    
    # Save as grid
    grid_path = os.path.join(save_dir, f'{prefix}_epoch_{epoch}.png')
    vutils.save_image(images, grid_path, normalize=True)


if __name__ == '__main__':
    # Test config loading
    test_config = {
        'exp_name': 'test',
        'output_dir': 'outputs',
        'training': {
            'lr': 0.0001,
            'batch_size': 8
        }
    }
    
    # Test save and load
    save_config(test_config, 'test_config.yaml')
    loaded_config = load_config('test_config.yaml')
    print("Config test passed!")
    print(loaded_config)
