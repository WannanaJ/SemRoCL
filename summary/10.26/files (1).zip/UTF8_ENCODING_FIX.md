# 🔧 UTF-8 ENCODING ERROR FIX
## Quick Solution for "UnicodeDecodeError: 'gbk' codec can't decode"

**Error You're Seeing:**
```
UnicodeDecodeError: 'gbk' codec can't decode byte 0x85 in position 50: illegal multibyte sequence
```

**Cause:**
- Your system uses GBK encoding by default (Chinese Windows)
- YAML file has UTF-8 characters (like ✅ checkmarks)
- Python can't read it without specifying UTF-8

---

## ⚡ QUICK FIX (2 Options)

### **Option 1: Use Clean Config File (Fastest - 30 seconds)**

Download and use the clean config without special characters:

```bash
# Replace your config with the clean version:
# Download: train_stage2_CLEAN.yaml
# Copy to: configs/train_stage2.yaml

# Then run:
python src/train_stage2_enhance.py --config configs/train_stage2.yaml
```

**[Download train_stage2_CLEAN.yaml](computer:///mnt/user-data/outputs/train_stage2_CLEAN.yaml)**

This file has:
- Same settings as the fixed version
- No special characters
- Will work on any system

---

### **Option 2: Fix utils.py (Permanent Solution - 1 minute)**

Update your `src/utils.py` to handle UTF-8:

**Find this in `src/utils.py` (around line 11):**
```python
def load_config(config_path):
    """Load YAML configuration file"""
    with open(config_path, 'r') as f:  # ❌ Missing encoding
        config = yaml.safe_load(f)
    return config
```

**Change to:**
```python
def load_config(config_path):
    """Load YAML configuration file with UTF-8 encoding"""
    with open(config_path, 'r', encoding='utf-8') as f:  # ✅ Added encoding
        config = yaml.safe_load(f)
    return config
```

**Also fix save_config (around line 18):**
```python
def save_config(config, save_path):
    """Save configuration to YAML file with UTF-8 encoding"""
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    with open(save_path, 'w', encoding='utf-8') as f:  # ✅ Added encoding
        yaml.dump(config, f, default_flow_style=False)
```

**Or download the complete fixed utils.py:**
**[Download utils_UTF8_FIX.py](computer:///mnt/user-data/outputs/utils_UTF8_FIX.py)**

Then:
```bash
cp utils_UTF8_FIX.py src/utils.py
```

---

## 🚀 RECOMMENDED APPROACH

Use **both** fixes for best results:

```bash
# Step 1: Fix utils.py (permanent fix)
# Add encoding='utf-8' to both open() calls in utils.py
# OR download and replace with utils_UTF8_FIX.py

# Step 2: Use clean config (works everywhere)
# Download train_stage2_CLEAN.yaml
# Replace configs/train_stage2.yaml

# Step 3: Restart training
python src/train_stage2_enhance.py --config configs/train_stage2.yaml
```

---

## 📋 TRAIN_STAGE2_CLEAN.YAML Contents

Here's what's in the clean config:

```yaml
# Stage 2: Enhancement Training Configuration
# FIXED VERSION with corrected learning rate and loss weights

exp_name: semantic_enhancement_stage2
output_dir: outputs

dataset:
  root_dir: D:/projects/SemRoCL/data/LOL-v1
  img_size: 384
  mode: paired

model:
  base_encoder: resnet50
  pretrained_encoder: outputs/moco_pretrain_stage1/checkpoints/moco_pretrain_final.pth
  semantic_backbone: segformer-b0
  num_classes: 19
  enhancer_channels: 32
  num_iterations: 8

training:
  epochs: 100
  batch_size: 8
  lr: 0.00001      # FIXED: Reduced from 0.0001
  num_workers: 4
  save_freq: 5

loss:
  # FIXED: Scaled loss weights to prevent explosion
  w_color: 0.1       # Reduced from 1.0
  w_semantic: 0.01   # Reduced from 1.0
  w_adv: 0.1         # Keep same
  w_freq: 0.01       # Reduced from 0.5
  w_task: 0.5        # Keep same
  w_perceptual: 1.0  # Keep same
```

---

## ✅ VERIFICATION

After applying the fix, test with:

```bash
# This should work without errors:
python src/train_stage2_enhance.py --config configs/train_stage2.yaml
```

You should see:
```
Using device: cuda
============================================================
Detecting semantic feature dimensions...
============================================================
```

If you see this, the UTF-8 error is fixed! ✅

---

## 🔍 WHY THIS HAPPENS

**Windows in Chinese Locale:**
- Default encoding: GBK (GB2312)
- Can't read UTF-8 special characters (✅, →, etc.)

**Solution:**
- Always specify `encoding='utf-8'` when opening files
- Or remove special characters from files

---

## 📥 FILES TO DOWNLOAD

1. **[train_stage2_CLEAN.yaml](computer:///mnt/user-data/outputs/train_stage2_CLEAN.yaml)** ⭐⭐⭐⭐⭐
   - Clean config without special characters
   - Same fixes applied (lr=0.00001, scaled loss weights)
   - Replace: `configs/train_stage2.yaml`

2. **[utils_UTF8_FIX.py](computer:///mnt/user-data/outputs/utils_UTF8_FIX.py)** ⭐⭐⭐⭐
   - Fixed utils.py with UTF-8 support
   - Replace: `src/utils.py`

3. **[train_stage2_enhance_FIXED.py](computer:///mnt/user-data/outputs/train_stage2_enhance_FIXED.py)** ⭐⭐⭐⭐⭐
   - Training script with gradient clipping
   - Replace: `src/train_stage2_enhance.py`

---

## 🎯 COMPLETE FIX CHECKLIST

- [ ] Download `train_stage2_CLEAN.yaml`
- [ ] Replace `configs/train_stage2.yaml`
- [ ] Download `utils_UTF8_FIX.py` (or manually add encoding='utf-8')
- [ ] Replace `src/utils.py`
- [ ] Download `train_stage2_enhance_FIXED.py`
- [ ] Replace `src/train_stage2_enhance.py`
- [ ] Run training command
- [ ] Verify no encoding errors
- [ ] Check G_loss drops from 5284 → ~5.5

---

## 📊 EXPECTED AFTER FIX

```bash
python src/train_stage2_enhance.py --config configs/train_stage2.yaml

# You should see:
Using device: cuda
============================================================
Detecting semantic feature dimensions...
============================================================
Number of feature levels: 4
  Level 0: shape=torch.Size([1, 64, 96, 96]), channels=64
  Level 1: shape=torch.Size([1, 128, 48, 48]), channels=128
  Level 2: shape=torch.Size([1, 320, 24, 24]), channels=320
  Level 3: shape=torch.Size([1, 512, 12, 12]), channels=512

Using 64 channels from first feature level
============================================================

Enhancer created with semantic_channels=64
Loaded pretrained encoder

============================================================
Training Configuration:
============================================================
  Batch size: 8
  Learning rate: 1e-05
  Epochs: 100
  Gradient clipping: 1.0
  Discriminator update freq: 5
  Loss explosion threshold: 50.0
============================================================

[LOL-v1|train] low=485, high=485

Epoch 1/100: 100%|████████| 61/61 [19:00<00:00]
├── G_loss: 5.5 ✅
├── D_loss: 0.45 ✅
```

---

**Status:** ✅ Fix Ready  
**Time Required:** 2 minutes  
**Difficulty:** Easy  

**Download the 3 files above and you're ready to train!** 🚀
