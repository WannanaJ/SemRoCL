# 🚀 Stage 2 Quick Start Guide

## ✅ Prerequisites Check

Before starting Stage 2, verify:

```bash
# 1. Stage 1 checkpoint exists
dir outputs\moco_pretrain_stage1\checkpoints\moco_pretrain_final.pth
# Should show: 369,857,660 bytes ✅

# 2. Paired dataset available
dir data\LOL-v1\our485\low      # Should have 485 images
dir data\LOL-v1\our485\high     # Should have 485 images

# 3. In correct directory
cd D:\projects\SemRoCL
```

---

## 📥 Step 1: Download Stage 2 Config

**[Download train_stage2.yaml](computer:///mnt/user-data/outputs/train_stage2.yaml)**

Save to: `D:\projects\SemRoCL\configs\train_stage2.yaml`

---

## 🔧 Step 2: Install Additional Dependencies (if needed)

```bash
# If you don't have SegFormer dependencies
pip install transformers --break-system-packages
pip install timm --break-system-packages
```

---

## ▶️ Step 3: Start Stage 2 Training

```bash
cd D:\projects\SemRoCL
conda activate semrocl

python src/train_stage2_enhance.py --config configs/train_stage2.yaml
```

---

## 📊 Expected Output

```
Using device: cuda
Loading datasets...
✅ [LOL-v1|train] low=485, high=485
Loading pretrained encoder from: outputs/moco_pretrain_stage1/checkpoints/moco_pretrain_final.pth
✅ Loaded checkpoint from epoch 200
Freezing encoder weights...
Initializing SegFormer-B0 semantic head...
Initializing curve-based enhancer...
Starting training...
Epoch 1/100:   0%|          | 0/60 [00:00<?, ?it/s]
```

---

## 🎯 What Stage 2 Does

### Architecture Components:

1. **Frozen Encoder** (from Stage 1)
   - Extracts robust low-light features
   - Weights remain fixed
   - No backpropagation through encoder

2. **Semantic Head** (SegFormer-B0)
   - Segments scenes into semantic regions
   - 19 classes (road, building, sky, etc.)
   - Provides semantic guidance

3. **Curve-Based Enhancer**
   - Learns pixel-wise enhancement curves
   - 8 iterative refinement steps
   - Preserves structure while enhancing

### Loss Functions:

```
Total Loss = 1.0 * Color Loss
           + 1.0 * Semantic Loss
           + 0.5 * Frequency Loss
           + 0.1 * Adversarial Loss
           + 0.5 * Task-specific Loss
           + 1.0 * Perceptual Loss
```

---

## 📈 Training Metrics to Watch

| Metric | Target | Meaning |
|--------|--------|---------|
| **PSNR** | 24-26 dB | Signal quality |
| **SSIM** | 0.85+ | Structural similarity |
| **LPIPS** | < 0.15 | Perceptual quality |
| **Color Loss** | Decreasing | RGB accuracy |
| **Semantic Loss** | Decreasing | Segmentation quality |

---

## ⏱️ Training Time Estimate

- **Epochs**: 100
- **Time per epoch**: ~4-5 minutes
- **Total time**: ~6-8 hours
- **Checkpoints**: Saved every 5 epochs

---

## 💾 Disk Space Requirements

- **Model checkpoints**: ~500-600 MB each
- **Total for all checkpoints**: ~10-12 GB
- **TensorBoard logs**: ~500 MB
- **Total needed**: ~15 GB free space

---

## 🐛 Common Issues & Solutions

### Issue 1: "Module not found: transformers"
**Solution:**
```bash
pip install transformers --break-system-packages
```

### Issue 2: "CUDA out of memory"
**Solution:** Reduce batch size in config:
```yaml
training:
  batch_size: 4  # Reduced from 8
```

### Issue 3: "Checkpoint not found"
**Solution:** Check path in config:
```yaml
model:
  pretrained_encoder: outputs/moco_pretrain_stage1/checkpoints/moco_pretrain_final.pth
```

### Issue 4: Training very slow
**Solution:** Reduce workers:
```yaml
training:
  num_workers: 2  # Reduced from 4
```

---

## 📊 Monitor Training

### Option 1: TensorBoard (Recommended)
```bash
# In a new terminal
conda activate semrocl
cd D:\projects\SemRoCL
tensorboard --logdir outputs/semantic_enhancement_stage2/logs

# Open: http://localhost:6006
```

### Option 2: Check Logs
```bash
# View latest checkpoint
dir outputs\semantic_enhancement_stage2\checkpoints
```

---

## 🎯 Success Indicators

✅ **Loss decreases smoothly**  
✅ **PSNR increases** (target: 24-26 dB)  
✅ **SSIM improves** (target: 0.85+)  
✅ **No CUDA errors**  
✅ **Checkpoints saving regularly**  

---

## 🚨 When to Stop Early

❌ **Stop if:**
- PSNR plateaus for 20+ epochs
- Loss stops decreasing
- CUDA out of memory (reduce batch size)
- Validation metrics deteriorate (overfitting)

✅ **Continue if:**
- Metrics still improving
- Loss decreasing
- GPU stable
- Checkpoints saving

---

## 📁 Output Structure

```
outputs/semantic_enhancement_stage2/
├── checkpoints/
│   ├── enhance_epoch_5.pth
│   ├── enhance_epoch_10.pth
│   ├── ...
│   ├── enhance_epoch_100.pth
│   └── enhance_final.pth
├── logs/
│   └── events.out.tfevents.*
├── results/
│   └── (enhanced images during validation)
└── visualizations/
    └── (comparison plots)
```

---

## 🎓 After Stage 2 Completes

### You'll have:
1. ✅ Fully trained enhancement model
2. ✅ Ready for inference on new images
3. ✅ Can evaluate on test set
4. ✅ Can deploy for real-world use

### Next steps:
```bash
# Evaluate on test set
python src/evaluate.py --config configs/eval.yaml

# Enhance single image
python src/inference.py --image path/to/image.jpg --output enhanced.jpg

# Batch process folder
python src/batch_process.py --input_dir low_light_images/ --output_dir enhanced/
```

---

## 💡 Pro Tips

1. **Run overnight** - Stage 2 takes 6-8 hours
2. **Monitor GPU temperature** - Use `nvidia-smi`
3. **Save config file** - For reproducibility
4. **Check intermediate results** - Validate quality every 20 epochs
5. **Compare with Stage 1** - Should see clear improvements

---

## 🎉 Ready to Start?

Make sure you have:
- [x] Stage 1 checkpoint (369 MB)
- [x] Stage 2 config downloaded
- [x] Paired dataset verified
- [x] GPU available
- [x] Enough disk space (~15 GB)

**Run this command:**
```bash
cd D:\projects\SemRoCL
python src/train_stage2_enhance.py --config configs/train_stage2.yaml
```

---

**Good luck with Stage 2!** 🚀

You're on the final stretch to having a fully trained low-light enhancement model!

