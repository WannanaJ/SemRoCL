# Stage 2 Training Analysis & Solutions
## Epoch 58 Loss Analysis

**Date:** October 26, 2025  
**Status:** Training Running but Issues Detected ⚠️

---

## 1. Current Training Status

### 1.1 Observed Metrics (Epoch 58)

```
Epoch 58/100: 100%|███████████| 61/61 [19:11<00:00, 18.87s/it]
├── G_loss (Generator): 5284.8203  ⚠️ VERY HIGH
├── D_loss (Discriminator): 0.0042  ⚠️ TOO LOW
├── Time per epoch: 19 minutes 11 seconds
└── Time per iteration: 18.87 seconds
```

---

## 2. Problem Analysis

### 2.1 🚨 Critical Issues

#### Issue 1: Exploding Generator Loss
```
G_loss = 5284.8203  ⚠️ EXTREMELY HIGH

Expected range: 2-10
Current: 5284.8 (500× too high!)

Symptoms:
✗ Generator loss is exploding
✗ Training is unstable
✗ Model likely producing artifacts
✗ Gradients may be exploding
```

#### Issue 2: Collapsed Discriminator
```
D_loss = 0.0042  ⚠️ TOO LOW

Expected range: 0.3-0.7
Current: 0.0042 (100× too low!)

Symptoms:
✗ Discriminator has collapsed
✗ Predicting everything as "real" or "fake"
✗ No longer providing useful gradients
✗ Generator not receiving adversarial feedback
```

### 2.2 Why This Happened

#### A. Loss Imbalance
```python
# In your loss computation:
losses['total'] = (
    1.0 * losses['color'] +        # Could be 100-500
    1.0 * losses['semantic'] +     # Could be 10-50
    0.1 * losses['adv'] +          # Should be 0.1-1
    0.5 * losses['freq'] +         # Could be 50-200
    1.0 * losses['perceptual'] +   # Could be 0.5-2
    0.1 * regularizations          # Could be 10-50
)

Problem:
- If semantic loss uses raw cross-entropy on 96×96 pixels
- If frequency loss on 384×384 is not normalized
- If perceptual loss not scaled properly
→ Total loss explodes!
```

#### B. Discriminator Over-Training
```python
# Discriminator updated every iteration
# Generator updated every iteration
# But discriminator is simpler and trains faster
→ Discriminator becomes too good
→ Generator can't fool it
→ Adversarial loss becomes useless
```

#### C. Missing Gradient Clipping
```python
# Without gradient clipping:
# Large losses → Large gradients → Weight explosion → Even larger losses
# This creates a positive feedback loop
```

---

## 3. Immediate Solutions

### 3.1 🔥 Emergency Fix: Loss Scaling

```python
# File: loss_functions.py or train_stage2_enhance.py
# Add after computing losses:

def scale_losses(losses):
    """
    Scale losses to prevent explosion
    """
    # Scale individual losses to reasonable ranges
    losses['color'] = losses['color'] * 0.1  # If using raw L1
    losses['semantic'] = losses['semantic'] * 0.01  # If using CE on 96×96
    losses['freq'] = losses['freq'] * 0.01  # If very large
    losses['perceptual'] = losses['perceptual']  # LPIPS already 0-1
    
    # Recompute total
    losses['total'] = (
        1.0 * losses['color'] +
        1.0 * losses['semantic'] +
        0.1 * losses['adv'] +
        0.5 * losses['freq'] +
        1.0 * losses['perceptual'] +
        0.1 * (losses.get('smooth', 0) + 
               losses.get('color_const', 0) + 
               losses.get('exposure', 0) + 
               losses.get('spatial', 0))
    )
    
    return losses

# Apply in training loop:
losses = criterion(enhanced, high, seg_logits_enh, seg_logits_tgt, 
                   confidence, disc_pred_fake)
losses = scale_losses(losses)  # ✅ Add this line
losses['total'].backward()
```

### 3.2 🛡️ Add Gradient Clipping

```python
# In train_stage2_enhance.py, after backward():

# Generator update
opt_G.zero_grad()
losses['total'].backward()

# ✅ ADD GRADIENT CLIPPING
torch.nn.utils.clip_grad_norm_(enhancer.parameters(), max_norm=1.0)
torch.nn.utils.clip_grad_norm_(semantic_head.parameters(), max_norm=1.0)

opt_G.step()

# Discriminator update
opt_D.zero_grad()
loss_D.backward()

# ✅ ADD GRADIENT CLIPPING
torch.nn.utils.clip_grad_norm_(discriminator.parameters(), max_norm=1.0)

opt_D.step()
```

### 3.3 ⚖️ Balance Discriminator Training

```python
# In train_stage2_enhance.py training loop:

# Add counter
disc_update_freq = 5  # Update discriminator every 5 iterations

for batch_idx, batch in enumerate(pbar):
    low = batch['low'].to(device)
    high = batch['high'].to(device)
    
    # === Generator Update (Every iteration) ===
    opt_G.zero_grad()
    
    seg_logits_enh, confidence = semantic_head(low)
    seg_logits_tgt, _ = semantic_head(high)
    semantic_features = semantic_head.get_semantic_features(low)[0]
    enhanced, curves = enhancer(low, semantic_features, confidence)
    disc_pred_fake = discriminator(enhanced)
    
    losses = criterion(enhanced, high, seg_logits_enh, seg_logits_tgt, 
                      confidence, disc_pred_fake)
    losses['total'].backward()
    
    torch.nn.utils.clip_grad_norm_(enhancer.parameters(), max_norm=1.0)
    torch.nn.utils.clip_grad_norm_(semantic_head.parameters(), max_norm=1.0)
    opt_G.step()
    
    # === Discriminator Update (Every N iterations) ===
    # ✅ Only update discriminator occasionally
    if batch_idx % disc_update_freq == 0:
        opt_D.zero_grad()
        
        disc_pred_real = discriminator(high)
        disc_pred_fake = discriminator(enhanced.detach())
        
        loss_D_real = adv_loss(disc_pred_real, True)
        loss_D_fake = adv_loss(disc_pred_fake, False)
        loss_D = (loss_D_real + loss_D_fake) * 0.5
        
        loss_D.backward()
        torch.nn.utils.clip_grad_norm_(discriminator.parameters(), max_norm=1.0)
        opt_D.step()
    else:
        loss_D = torch.tensor(0.0)
    
    pbar.set_postfix({
        'G_loss': f'{losses["total"].item():.4f}',
        'D_loss': f'{loss_D.item():.4f}'
    })
```

### 3.4 📊 Add Detailed Logging

```python
# In training loop, add detailed loss breakdown:

if batch_idx % 10 == 0:  # Every 10 iterations
    writer.add_scalar('Loss/G_total', losses['total'].item(), global_step)
    writer.add_scalar('Loss/G_color', losses['color'].item(), global_step)
    writer.add_scalar('Loss/G_semantic', losses['semantic'].item(), global_step)
    writer.add_scalar('Loss/G_adv', losses['adv'].item(), global_step)
    writer.add_scalar('Loss/G_freq', losses['freq'].item(), global_step)
    writer.add_scalar('Loss/G_perceptual', losses['perceptual'].item(), global_step)
    writer.add_scalar('Loss/D', loss_D.item(), global_step)
    
    # Log individual loss magnitudes
    print(f"\nDetailed losses at step {global_step}:")
    print(f"  Color: {losses['color'].item():.4f}")
    print(f"  Semantic: {losses['semantic'].item():.4f}")
    print(f"  Adversarial: {losses['adv'].item():.4f}")
    print(f"  Frequency: {losses['freq'].item():.4f}")
    print(f"  Perceptual: {losses['perceptual'].item():.4f}")
    print(f"  Discriminator: {loss_D.item():.4f}")
    print(f"  TOTAL: {losses['total'].item():.4f}\n")
```

---

## 4. Quick Fix Script

### 4.1 Apply All Fixes At Once

```python
# File: fix_training.py
# Run this to patch your training script

import os
import re

def patch_training_script():
    """
    Automatically patch train_stage2_enhance.py with all fixes
    """
    
    script_path = 'src/train_stage2_enhance.py'
    
    with open(script_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Backup original
    with open(script_path + '.backup_losses', 'w', encoding='utf-8') as f:
        f.write(content)
    
    # Fix 1: Add gradient clipping after Generator backward
    old_pattern1 = """            losses['total'].backward()
            opt_G.step()"""
    
    new_pattern1 = """            losses['total'].backward()
            # Gradient clipping
            torch.nn.utils.clip_grad_norm_(enhancer.parameters(), max_norm=1.0)
            torch.nn.utils.clip_grad_norm_(semantic_head.parameters(), max_norm=1.0)
            opt_G.step()"""
    
    content = content.replace(old_pattern1, new_pattern1)
    
    # Fix 2: Add gradient clipping after Discriminator backward
    old_pattern2 = """            loss_D.backward()
            opt_D.step()"""
    
    new_pattern2 = """            loss_D.backward()
            # Gradient clipping
            torch.nn.utils.clip_grad_norm_(discriminator.parameters(), max_norm=1.0)
            opt_D.step()"""
    
    content = content.replace(old_pattern2, new_pattern2)
    
    # Fix 3: Reduce learning rate (add after creating optimizers)
    # This should be done in config, but can be patched
    
    # Fix 4: Add detailed logging
    logging_code = """
            # Detailed logging every 10 iterations
            if batch_idx % 10 == 0:
                writer.add_scalar('Loss/G_color', losses.get('color', 0).item(), epoch * len(train_loader) + batch_idx)
                writer.add_scalar('Loss/G_semantic', losses.get('semantic', 0).item(), epoch * len(train_loader) + batch_idx)
                writer.add_scalar('Loss/G_adv', losses.get('adv', 0).item(), epoch * len(train_loader) + batch_idx)
                writer.add_scalar('Loss/D', loss_D.item(), epoch * len(train_loader) + batch_idx)
"""
    
    # Find location after pbar.set_postfix and insert
    insert_pos = content.find("pbar.set_postfix({")
    if insert_pos != -1:
        # Find end of set_postfix
        end_pos = content.find("})", insert_pos) + 2
        content = content[:end_pos] + "\n" + logging_code + content[end_pos:]
    
    # Write patched version
    with open(script_path, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print("✅ Training script patched!")
    print(f"   Backup saved: {script_path}.backup_losses")
    print("\nApplied fixes:")
    print("  1. Gradient clipping (max_norm=1.0)")
    print("  2. Detailed loss logging")
    print("\nNext steps:")
    print("  1. Stop current training (Ctrl+C)")
    print("  2. Reduce learning rate in config (0.0001 → 0.00001)")
    print("  3. Resume training from last checkpoint")

if __name__ == '__main__':
    patch_training_script()
```

### 4.2 Config File Updates

```yaml
# File: configs/train_stage2.yaml
# Update these values:

training:
  epochs: 100
  batch_size: 8
  lr: 0.00001  # ✅ REDUCED from 0.0001 (10x smaller)
  num_workers: 4
  save_freq: 5

loss:
  w_color: 0.1        # ✅ REDUCED from 1.0
  w_semantic: 0.01    # ✅ REDUCED from 1.0
  w_adv: 0.1          # Keep same
  w_freq: 0.01        # ✅ REDUCED from 0.5
  w_task: 0.5         # Keep same
  w_perceptual: 1.0   # Keep same (LPIPS is already 0-1)
```

---

## 5. Diagnosis: What Each Loss Should Be

### 5.1 Expected Loss Ranges

```python
"""
At convergence, losses should be approximately:

Generator Losses:
├── Color Loss (L1):           0.05 - 0.15
├── SSIM Loss:                 0.10 - 0.30
├── Semantic Loss (CE):        0.50 - 2.00
├── Adversarial Loss:          0.30 - 0.70
├── Frequency Loss:            0.10 - 0.50
├── Perceptual Loss (LPIPS):   0.05 - 0.20
└── Regularizations:           0.01 - 0.10 each

Total Generator Loss: 2.0 - 10.0 ✅
Current: 5284.8 ❌ (500× too high)

Discriminator Loss:
├── Real predictions:          0.30 - 0.50
├── Fake predictions:          0.30 - 0.50
└── Total D Loss:              0.30 - 0.70 ✅

Current: 0.0042 ❌ (100× too low)
"""
```

### 5.2 Check Individual Losses

```python
# Add this to your training loop to diagnose:

def diagnose_losses(losses, loss_D):
    """Print loss diagnosis"""
    
    issues = []
    
    # Check each loss
    if losses.get('color', 0) > 1.0:
        issues.append(f"⚠️ Color loss too high: {losses['color']:.4f} (should be 0.05-0.15)")
    
    if losses.get('semantic', 0) > 5.0:
        issues.append(f"⚠️ Semantic loss too high: {losses['semantic']:.4f} (should be 0.5-2.0)")
    
    if losses.get('freq', 0) > 1.0:
        issues.append(f"⚠️ Frequency loss too high: {losses['freq']:.4f} (should be 0.1-0.5)")
    
    if losses.get('perceptual', 0) > 0.5:
        issues.append(f"⚠️ Perceptual loss too high: {losses['perceptual']:.4f} (should be 0.05-0.2)")
    
    if losses['total'] > 20:
        issues.append(f"🚨 TOTAL LOSS CRITICAL: {losses['total']:.4f} (should be 2-10)")
    
    if loss_D < 0.1:
        issues.append(f"⚠️ Discriminator collapsed: {loss_D:.4f} (should be 0.3-0.7)")
    
    if issues:
        print("\n" + "="*70)
        print("LOSS DIAGNOSIS:")
        for issue in issues:
            print(f"  {issue}")
        print("="*70 + "\n")
    
    return len(issues) > 0

# In training loop:
has_issues = diagnose_losses(losses, loss_D)
if has_issues and batch_idx % 50 == 0:
    # Save checkpoint in case training needs to be restarted
    save_checkpoint({...}, f'emergency_checkpoint_epoch_{epoch}.pth')
```

---

## 6. Recovery Strategy

### 6.1 Option 1: Continue with Fixes (Recommended)

```bash
# 1. Stop current training
# Press Ctrl+C in terminal

# 2. Apply fixes
python fix_training.py

# 3. Update config
# Edit configs/train_stage2.yaml
# Reduce learning rate: 0.0001 → 0.00001
# Reduce loss weights as shown above

# 4. Resume from last good checkpoint
# Find checkpoint before explosion (epoch 40-50?)
python src/train_stage2_enhance.py --config configs/train_stage2.yaml --resume outputs/semantic_enhancement_stage2/checkpoints/stage2_epoch_50.pth
```

### 6.2 Option 2: Restart from Scratch

```bash
# 1. Apply all fixes first
python fix_training.py

# 2. Update config with reduced LR and loss weights

# 3. Start fresh training
python src/train_stage2_enhance.py --config configs/train_stage2.yaml
```

### 6.3 Option 3: Emergency Stabilization

```python
# Add to training loop - emergency brake:

MAX_LOSS_THRESHOLD = 50.0
loss_history = []

for batch_idx, batch in enumerate(pbar):
    # ... training code ...
    
    # Emergency brake
    if losses['total'].item() > MAX_LOSS_THRESHOLD:
        print(f"\n🚨 EMERGENCY STOP: Loss exceeded {MAX_LOSS_THRESHOLD}")
        print(f"   Current loss: {losses['total'].item():.4f}")
        print(f"   Saving emergency checkpoint...")
        
        save_checkpoint({
            'epoch': epoch,
            'batch': batch_idx,
            'enhancer': enhancer.state_dict(),
            'semantic_head': semantic_head.state_dict(),
            'discriminator': discriminator.state_dict(),
            'optimizer_G': opt_G.state_dict(),
            'optimizer_D': opt_D.state_dict()
        }, 'emergency_checkpoint_before_explosion.pth')
        
        # Option 1: Stop training
        raise Exception("Training unstable - manual intervention required")
        
        # Option 2: Reset learning rate and continue
        # for param_group in opt_G.param_groups:
        #     param_group['lr'] *= 0.1
        # for param_group in opt_D.param_groups:
        #     param_group['lr'] *= 0.1
        # print("   Reduced learning rate by 10x, continuing...")
    
    loss_history.append(losses['total'].item())
    if len(loss_history) > 100:
        loss_history.pop(0)
```

---

## 7. Long-term Improvements

### 7.1 Better Loss Normalization

```python
class NormalizedCombinedLoss(nn.Module):
    """
    Self-normalizing combined loss
    """
    
    def __init__(self, config):
        super().__init__()
        self.config = config
        
        # Track running statistics
        self.register_buffer('color_mean', torch.tensor(0.1))
        self.register_buffer('semantic_mean', torch.tensor(1.0))
        self.register_buffer('freq_mean', torch.tensor(0.3))
        self.momentum = 0.99
    
    def forward(self, enhanced, target, seg_logits_enh, seg_logits_tgt, 
                confidence, disc_pred_fake):
        """
        Compute losses with automatic normalization
        """
        
        # Compute raw losses
        color_loss = self.color_loss(enhanced, target)
        semantic_loss = self.semantic_loss(seg_logits_enh, seg_logits_tgt, confidence)
        freq_loss = self.frequency_loss(enhanced, target)
        perceptual_loss = self.lpips(enhanced, target)
        adv_loss = self.adversarial_loss(disc_pred_fake, True)
        
        # Update running means (EMA)
        with torch.no_grad():
            self.color_mean = self.momentum * self.color_mean + \
                             (1 - self.momentum) * color_loss.detach()
            self.semantic_mean = self.momentum * self.semantic_mean + \
                                (1 - self.momentum) * semantic_loss.detach()
            self.freq_mean = self.momentum * self.freq_mean + \
                            (1 - self.momentum) * freq_loss.detach()
        
        # Normalize by running means
        color_loss_norm = color_loss / (self.color_mean + 1e-8)
        semantic_loss_norm = semantic_loss / (self.semantic_mean + 1e-8)
        freq_loss_norm = freq_loss / (self.freq_mean + 1e-8)
        
        # Combine with weights
        total_loss = (
            self.config['w_color'] * color_loss_norm +
            self.config['w_semantic'] * semantic_loss_norm +
            self.config['w_adv'] * adv_loss +
            self.config['w_freq'] * freq_loss_norm +
            self.config['w_perceptual'] * perceptual_loss
        )
        
        losses = {
            'color': color_loss,
            'semantic': semantic_loss,
            'freq': freq_loss,
            'perceptual': perceptual_loss,
            'adv': adv_loss,
            'total': total_loss
        }
        
        return losses
```

### 7.2 Adaptive Learning Rate

```python
# Use ReduceLROnPlateau scheduler

from torch.optim.lr_scheduler import ReduceLROnPlateau

scheduler_G = ReduceLROnPlateau(
    opt_G, mode='min', factor=0.5, patience=5, verbose=True
)

scheduler_D = ReduceLROnPlateau(
    opt_D, mode='min', factor=0.5, patience=5, verbose=True
)

# After each epoch:
scheduler_G.step(epoch_loss_G)
scheduler_D.step(epoch_loss_D)
```

### 7.3 Exponential Moving Average (EMA)

```python
class EMA:
    """
    Exponential Moving Average for stable training
    """
    
    def __init__(self, model, decay=0.999):
        self.model = model
        self.decay = decay
        self.shadow = {}
        self.backup = {}
        
        for name, param in model.named_parameters():
            if param.requires_grad:
                self.shadow[name] = param.data.clone()
    
    def update(self):
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                self.shadow[name] = self.decay * self.shadow[name] + \
                                   (1 - self.decay) * param.data
    
    def apply_shadow(self):
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                self.backup[name] = param.data
                param.data = self.shadow[name]
    
    def restore(self):
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                param.data = self.backup[name]
        self.backup = {}

# Usage:
ema_enhancer = EMA(enhancer, decay=0.999)

# In training loop:
opt_G.step()
ema_enhancer.update()  # Update EMA weights

# For evaluation:
ema_enhancer.apply_shadow()  # Use EMA weights
evaluate(enhancer, val_loader)
ema_enhancer.restore()  # Restore training weights
```

---

## 8. Summary & Action Plan

### 8.1 Immediate Actions (Do Now!)

1. **✅ Stop Training** (Ctrl+C if needed)

2. **✅ Apply Gradient Clipping:**
   ```python
   torch.nn.utils.clip_grad_norm_(enhancer.parameters(), max_norm=1.0)
   torch.nn.utils.clip_grad_norm_(semantic_head.parameters(), max_norm=1.0)
   torch.nn.utils.clip_grad_norm_(discriminator.parameters(), max_norm=1.0)
   ```

3. **✅ Reduce Learning Rate:**
   ```yaml
   lr: 0.00001  # From 0.0001
   ```

4. **✅ Scale Loss Weights:**
   ```yaml
   w_color: 0.1       # From 1.0
   w_semantic: 0.01   # From 1.0
   w_freq: 0.01       # From 0.5
   ```

5. **✅ Resume Training:**
   ```bash
   python src/train_stage2_enhance.py --config configs/train_stage2.yaml
   ```

### 8.2 Expected Results After Fixes

```
After applying fixes:

Epoch 59/100: 100%|███| 61/61 [19:00<00:00]
├── G_loss: ~5.5 ✅ (down from 5284)
├── D_loss: ~0.45 ✅ (up from 0.004)
└── Training: Stable ✅

Epoch 65/100: 100%|███| 61/61 [19:00<00:00]
├── G_loss: ~3.2 ✅ (continuing to decrease)
├── D_loss: ~0.52 ✅ (stable)
└── Images: Improving quality ✅

Epoch 80/100: 100%|███| 61/61 [19:00<00:00]
├── G_loss: ~2.5 ✅ (converging)
├── D_loss: ~0.48 ✅ (balanced)
└── Model: Ready for evaluation ✅
```

### 8.3 How to Monitor Progress

```bash
# Terminal 1: Run training
python src/train_stage2_enhance.py --config configs/train_stage2.yaml

# Terminal 2: Monitor with TensorBoard
tensorboard --logdir=outputs/semantic_enhancement_stage2/logs --port=6006

# Open browser: http://localhost:6006
# Watch:
#   - Loss/G_total should decrease steadily
#   - Loss/D should stay in 0.3-0.7 range
#   - Individual losses should be reasonable
```

---

**Priority:** Apply gradient clipping and reduce learning rate immediately! Your training is unstable but recoverable. 🚀

Good luck with the fixes!

