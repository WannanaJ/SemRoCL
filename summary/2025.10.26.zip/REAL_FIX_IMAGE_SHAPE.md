# 🔧 Real Fix for Image Shape Issue

## The Problem

Error shows: `input[8, 384, 384, 3]` but model expects: `[8, 3, 384, 384]`

The issue is in `data_loader.py` - when processing **paired** data (high/normal images), the code uses a different path that treats `high` as a mask!

## The Root Cause

In `data_loader.py` line ~135:

```python
out = self.tf(image=low, mask=high)  # ❌ WRONG!
low_t, high_t = out["image"], out["mask"]  #  mask stays in HWC format!
```

When you pass an image as `mask` to Albumentations, it doesn't convert HWC → CHW!

## The Solution

### Option 1: Python One-Liner (Fastest)

```python
filepath = r"D:\projects\SemRoCL\src\data_loader.py"
with open(filepath, 'r', encoding='utf-8') as f:
    content = f.read()

# Backup
with open(filepath + '.backup_real', 'w', encoding='utf-8') as f:
    f.write(content)

# Fix: Apply transforms to both images separately
old_code = """            out = self.tf(image=low, mask=high)
            low_t, high_t = out["image"], out["mask"]"""

new_code = """            # Apply same transform to both images
            transformed = self.tf(image=low)
            low_t = transformed["image"]
            # Apply same transform to high image
            transformed_high = self.tf(image=high)
            high_t = transformed_high["image"]"""

content = content.replace(old_code, new_code)

with open(filepath, 'w', encoding='utf-8') as f:
    f.write(content)

print("✅ Fixed! Both images now use 'image' parameter (CHW format)")
```

### Option 2: Better Fix with Replay

If you want to ensure the SAME augmentation is applied to both:

```python
# This ensures paired images get the exact same augmentation
import albumentations as A
from albumentations.core.transforms_interface import to_tuple

# In __getitem__, replace the paired section with:
if self.paired and idx < len(self.high_paths):
    high_p = self.high_paths[idx]
    high = cv2.imread(high_p, cv2.IMREAD_COLOR)
    high = cv2.cvtColor(high, cv2.COLOR_BGR2RGB)
    
    # Apply same transform with replay
    transformed_low = self.tf(image=low)
    low_t = transformed_low["image"]
    
    # For high, apply same augmentation
    if self.augment:
        # Use ReplayCompose for paired data
        # For now, just transform separately
        transformed_high = self.tf(image=high)
        high_t = transformed_high["image"]
    else:
        # For validation, same transforms apply
        transformed_high = self.tf(image=high)
        high_t = transformed_high["image"]
else:
    low_t = self.tf(image=low)["image"]
```

## Quick Manual Fix

1. Open: `D:\projects\SemRoCL\src\data_loader.py`
2. Find line ~133-135:
```python
out = self.tf(image=low, mask=high)
low_t, high_t = out["image"], out["mask"]
```

3. Replace with:
```python
# Transform low image
low_transformed = self.tf(image=low)
low_t = low_transformed["image"]

# Transform high image separately
high_transformed = self.tf(image=high)
high_t = high_transformed["image"]
```

4. Save and run training again!

## Why This Works

- `image=` parameter → ToTensorV2 converts HWC → CHW ✅
- `mask=` parameter → Stays in HWC format ❌

By using `image=` for both, both get converted to CHW format properly!

## After Fixing

Run training:
```bash
python src/train_stage2_enhance.py --config configs/train_stage2.yaml
```

Expected output:
```
Epoch 1/100:   2%|█ | 1/61 [00:05<05:20, 5.34s/it]
```

No more shape errors! 🎉
