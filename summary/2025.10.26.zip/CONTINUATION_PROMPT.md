# SemRoCL Stage 2 Training - Continuation Prompt

## Context Summary

I'm working on a **SemRoCL (Semantic-Guided Robust Contrastive Learning)** project for low-light image enhancement. The project has two stages:

### Stage 1: ✅ COMPLETED
- **Task:** MoCo v3 contrastive pretraining on low-light images
- **Status:** Successfully trained for 200 epochs
- **Loss:** 6.9 → 3.87 (44% improvement)
- **Output:** Pretrained ResNet-50 encoder checkpoint (369.9 MB)
- **Dataset:** LOL-v1 (485 training images)
- **Problems Solved:** 
  - Parameter naming issues (`mode` vs `paired`)
  - UTF-8 encoding errors
  - Image size mismatches (512→384)
  - Syntax errors (missing commas)

### Stage 2: ❌ CURRENT ISSUE
**Task:** Semantic-guided enhancement training

**Architecture:**
```
Input (low-light) → Pretrained Encoder (frozen) → Semantic Head → Enhancer → Output (enhanced)
                                                      ↓
                                                Semantic Features
```

**Components:**
1. **Pretrained Encoder:** Frozen ResNet-50 from Stage 1
2. **Semantic Head:** SegFormer-B0 (19 classes, semantic segmentation)
3. **Enhancer:** Curve-based enhancement with semantic fusion
4. **Discriminator:** PatchGAN for adversarial training

## Current Error

```
RuntimeError: Given groups=1, weight of size [32, 160, 1, 1], 
expected input[8, 64, 384, 384] to have 160 channels, but got 64 channels instead
```

**Error Location:** `enhancer.py` line 82 in `semantic_fusion` module

**Root Cause:** Channel mismatch in semantic fusion
- Enhancer expects: `n_channels(32) + 128 = 160` channels
- Actually receiving: `n_channels(32) + 64 = 96` channels (but error shows only 64?)
- The semantic features from `SemanticHead` are 64 channels, not 128 as assumed

## Code Files

### 1. `enhancer.py` (CurveEnhancer class)
```python
# Semantic fusion module (LINE ~40-43)
if self.use_semantic:
    self.semantic_fusion = nn.Sequential(
        nn.Conv2d(n_channels + 128, n_channels, 1, 1, 0),  # ❌ Assumes 128-dim
        nn.ReLU(inplace=True)
    )
```

### 2. `train_stage2_enhance.py`
```python
# Line 88 - Enhancement call
enhanced, curves = enhancer(low, semantic_features, confidence)

# Line 83 - Semantic features extraction
semantic_features = semantic_head.get_semantic_features(low)[0]
```

### 3. `data_loader.py`
- Already fixed for CHW format (using `image=` parameter, not `mask=`)
- Returns: `{"low": [B,3,H,W], "high": [B,3,H,W]}`

### 4. `train_stage2.yaml`
```yaml
model:
  enhancer_channels: 32  # n_channels
  semantic_backbone: segformer-b0
```

## What I Need

**Please help me:**

1. **Identify the actual channel dimension** of semantic features from `SemanticHead.get_semantic_features()`
2. **Fix the channel mismatch** in `enhancer.py` semantic_fusion module
3. **Ensure compatibility** between semantic head output and enhancer input
4. **Create fixed versions** of the affected files

## Additional Context

- The semantic head uses SegFormer-B0 backbone
- Features might be multi-scale (different resolutions)
- The `get_semantic_features()` method returns a list/tuple of features
- We're using `[0]` to get the first feature map, which might be 64 channels

## Files I Can Provide

I have these files available:
- `enhancer.py` - Curve enhancer with semantic fusion
- `train_stage2_enhance.py` - Stage 2 training script
- `semantic_head.py` - (if needed) Semantic segmentation head
- `data_loader.py` - Dataset loader
- `train_stage2.yaml` - Configuration file

## Expected Solution

The fix should:
1. Update `semantic_fusion` to accept the correct number of channels
2. Make the channel dimension configurable (not hardcoded to 128)
3. Handle potential multi-scale semantic features
4. Ensure forward pass works end-to-end

## Previous Similar Issues Solved

1. **Data loader image format:** Fixed by using `image=` parameter for both images (not `mask=`)
2. **Parameter naming:** Changed `mode='unpaired'` to `paired=False`
3. **Image size:** Reduced from 512 to 384 to fit dataset

## System Info

- **OS:** Windows 10
- **GPU:** CUDA-enabled
- **Framework:** PyTorch
- **Dataset:** LOL-v1 (485 paired images, 384×384)
- **Batch size:** 8
- **Device:** CUDA

## Quick Start Request

Please analyze the channel mismatch and provide:
1. Root cause explanation
2. Fixed `enhancer.py` code
3. Any necessary changes to `train_stage2_enhance.py`
4. Verification that dimensions will match correctly

Thank you!
